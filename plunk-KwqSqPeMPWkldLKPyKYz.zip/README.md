### Follow these Instructions to Add a new Module / Page to this App

    Note: Replace <MODULE> with the name/identifier (lowercase unless otherwise specified) of the new module/page (e.g.: gallery, chat, profile, etc.)

1. Create a new CONTROLLER (business logic) for the new page.
    * create the file: **scripts/modules/<MODULE>/<MODULE>-controller.js**
    * create the CONTROLLER CODE, giving it the name of **<MODULE>Controller** (use CamelCase e.g.: **ForumController**, where **forum** is the module name)
```
      // this is the name of the controller (CamelCase), it's case sensitive, will be used at step 4
      app.controller ('<MODULE>Controller', [
        '$scope', function ( $scope ) {
              
          // code here
          // ...
              
        }
      ]);
```
2. Create a new HTML VIEW for the new module.
    * create the file: **scripts/modules/<MODULE>/<MODULE>-view.html**
    * create the base VIEW CODE as follows:
```
      <!-- <MODULE> CSS RULES / STYLES -->
      <style>
        
        #<MODULE>-view {
          color: green;
        }
        
      </style>
      
      <!-- <MODULE> VIEW STRUCTURE -->
      <div id="<MODULE>-view">
        This is the <MODULE> Page!
      </div>
```
3. Link the new CONTROLLER file to **index.html**
    * add a new **<script>** tag just above the end of the **</head>** tag, following the layout of the existing code
```
      <script src="scripts/modules/<MODULE>/<MODULE>-controller.js"></script>
```
4. Add a new ROUTE in **scripts/angular-startup.js** before the **.otherwise()**, and after the last **.when()** (copy-paste the existing route template example)
    * code should look like this:
```
      .when (
        '/<MODULE>', { // don't forget the "/" in front of the module name
          templateUrl: 'scripts/modules/<MODULE>/<MODULE>-view.html',
          controller: '<MODULE>Controller' // (must be the same name you gave the controller at step 1)
        }
      )
```
5. Add a new NAVIGATION MENU ITEM (<a>) in **index.html** within the <div class="navbar-nav"></div> tag (follow the layout of the existing menu items)
```
      <!-- Don't forget the "!/" (yes, exclamation point & forward slash) right after "#" so it becomes "#!/" -->
      <!-- Also, don't change anything else apart from the contents of the "href" attribute, so only replace <MODULE> with the name of the module/page -->
      <a class="nav-item nav-link" href="#!/<MODULE>" data-toggle="collapse" data-target="#myForumNavbar" aria-controls="myForumNavbar">
        <MODULE>
      </a>
```
6. PROFIT!