/** create a new AngularJS app instance **/
var app = angular.module ( 'My-Forum', [ 'ngRoute', 'ngStorage' ] );

app.config ([ 
  '$routeProvider', function ( $routeProvider ) {

		/** DEFAULT APP MODULE / PAGE - this will load when the user first loads the app **/
		var defaultRoute = '/home';

		/** ROUTE CONFIGURATION - WHEN USER ACCESSES THE FOLLOWING LINKS, LOAD THE APPROPRIATE VIEWS / PAGES **/
		$routeProvider
		  
		  /** FORUM MODULE **/
			.when (
				'/forum', {
					templateUrl: 'scripts/modules/forum/forum-view.html',
					controller: 'ForumController'
				}
			)
			
			/** PROFILE MODULE **/
			.when (
				'/profile', {
					templateUrl: 'scripts/modules/profile/profile-view.html',
					controller: 'ProfileController'
				}
			)
			
			/** HOME MODULE **/
			.when (
				'/home', {
					templateUrl: 'scripts/modules/home/home-view.html',
					controller: 'HomeController'
				}
			)
			
			/** LOGIN MODULE **/
			.when (
				'/login', {
					templateUrl: 'scripts/modules/login/login-view.html',
					controller: 'LoginController'
				}
			)
			
			/** REGISTRATION MODULE **/
			.when (
				'/registration', {
					templateUrl: 'scripts/modules/registration/registration-view.html',
					controller: 'RegistrationController'
				}
			)
			
			/** LOGOUT MODULE **/
			.when (
				'/logout', {
					template: '',
					controller: 'LogoutController'
				}
			)
			
			/**
			// NEW MODULE AngularJS ROUTE TEMPLATE
			// replace <MODULE> with the name of the new module / page
			// make sure you add a MENU LINK in index.html once you add a new module
			.when (
				'/MODULE', {
					templateUrl: 'scripts/modules/<MODULE>/<MODULE>-view.html',
					controller: '<MODULE>Controller' // controller name must be CamelCase
				}
			)
			**/
			
			/** IF THE USER REQUESTS AN UNRECOGNISED OR NO LINK, REDIRECT THEM TO THE DEFAULT ONE **/
			.otherwise (
				{
					redirectTo: defaultRoute
				}
			);
	}
]);

/** code to run once the AngularJS app instance was fully set up, before any pages are shown / rendered **/
app.run ([
  '$rootScope', '$location', 'AuthenticationService', function($rootScope, $location, auth) {
    
    /** DEVELOPMENT CODE - REMOVE IN PRODUCTION **/
    if (auth.AuthenticateUser('asd@asd.asd', 'asd')) {
      $location.path('/profile');
    }
    
    /** code to run when a new page has just been requested **/
    $rootScope.$on('$routeChangeStart', function(angularEvent, next, current) {
      
      // oputput parameter values to console for debug purposes
      //console.log('$routeChangeStart');
      //console.log(angularEvent);
      //console.log(next);
      //console.log(current);
      
      /** add new pages here as the app expands **/
      var requiresAuthentication = {
        '/forum': true,
        '/profile': true
      };
      
      var requiresAnonymous = {
        '/login': true,
        '/registration': true
      };
      
      if (requiresAuthentication[next.originalPath] == true && auth.User() == null) {
        
        $location.path('/login');
        
      } 
      
      if (requiresAnonymous[next.originalPath] == true && auth.User() != null) {
        
        $location.path('/home');
        
      }
      
    });
    
    /** code to run when a new page has just been successfully loaded **/
    $rootScope.$on('$routeChangeSuccess', function (angularEvent, current, previous) {
      
      // oputput parameter values to console for debug purposes
      //console.log('$routeChangeSuccess');
      //console.log(angularEvent);
      //console.log(current);
      //console.log(previous);
      
    });
    
    /** code to run when the requested page could not be loaded **/
    $rootScope.$on('$routeChangeError', function (angularEvent, current, previous, rejection) {
  
      // oputput parameter values to console for debug purposes
      //console.log('$routeChangeError');
      //console.log(angularEvent);
      //console.log(current);
      //console.log(previous);
      //console.log(rejection);
  
    });
    
  }
])