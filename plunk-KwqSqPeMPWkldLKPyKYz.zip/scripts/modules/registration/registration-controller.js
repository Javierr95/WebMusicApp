app.controller ('RegistrationController', [
	'$scope', '$timeout', 'AuthenticationService', '$location', function ( $scope, $timeout, auth, $location )
	{
		  
    /** oputput parameter values to console for debug purposes **/
    console.log('RegistrationController has loaded.');
		  
    /****** CONTROLLER CODE ******/
    
    /** public ($scope) variables **/
    $scope.user = {
      email: '',
      password: '',
      passwordConfirm: '',
      name: ''
    };
    
    /** private variables **/
    // 
    
    /** constructor **/
    var _initialise = function () {
      //
    };
    
    /** public ($scope) methods **/
    $scope.RegisterUser = function () {
      
      var proceed = true;
      
      // check if email exists
      if (auth.GetUserByEmail($scope.user.email) != null) {
          
        // email already exists
        proceed = false;
        
      }
      
      // check if passwords match
      if ($scope.user.password != $scope.user.passwordConfirm) {
       
        // passwords don't match
        proceed = false;
        
      }
      
      if (!proceed) {
        
        return;
      }
        
      // create new user object
      var user = {
        email: $scope.user.email,
        password: auth.EncryptPassword($scope.user.password),
        name: $scope.user.name
      };
      
      // add to authentication's users' database
      auth.AddUser(user);
      
      // login the user
      auth.AuthenticateUser(user.email, user.password);
      
      // redirect to forum straight away
      $location.path("/forum");
      
    };
    
    $scope.ShowAllUsers = function () {
      
      return auth.GetAllUsers();
      
    };
    
    /** private methods **/
    //
    
    /** initialise controller **/
    _initialise();

	}
]);












