app.controller ('ProfileController', [
	'$scope', 'AuthenticationService',  function ( $scope, auth )
	{
		  
    /** oputput parameter values to console for debug purposes **/
    console.log('ProfileController has loaded.');
    console.log('$scope:', $scope);
		  
    /****** CONTROLLER CODE ******/
    
    /** public attributes / variables **/
    $scope.profileFormModel = {
      name: auth.User().name, // make form field contain the user's name at the start
      email: auth.User().email, // make form field contain the user's email at the start
      password: '',
      newPassword: '',
      passwordConfirm: ''
    };
    $scope.invalidCurrentPassword = false;
    
    /** private attributes / variables **/
    //
    
    /** constructor / startup method **/
    var _initialise = function () {
      //
    }
    
    /** public behaviour / methods **/
    $scope.User = function () { 
      return auth.User();
    };
    
    $scope.UpdateUserProfile = function () {
      
      // check existing password
      $scope.invalidCurrentPassword = !auth.AuthenticateUser($scope.User().email, $scope.profileFormModel.password);
      
      if ($scope.invalidCurrentPassword) {
        
        // invalid current password
        return;
        
      } 
      
      if ($scope.profileFormModel.newPassword !== '' && $scope.profileFormModel.newPassword !== $scope.profileFormModel.passwordConfirm) {
        
        // new password was supplied and the two sets do not match
        return;
        
      }
      
      var userData = {
        name: $scope.profileFormModel.name,
        email: $scope.profileFormModel.email,
        index: $scope.User().index
      };
      
      // if new password was supplied, then include it in the userData object
      if ($scope.profileFormModel.newPassword !== '') {
        
        userData.password = auth.EncryptPassword($scope.profileFormModel.newPassword);
        
        // empty the new password view fields
        $scope.profileFormModel.newPassword = '';
        $scope.profileFormModel.passwordConfirm = '';
        
      }
      
      // empty the password view field
      $scope.profileFormModel.password = '';
      
      
      // reset form validation status - https://stackoverflow.com/questions/18648427/angular-clear-subform-data-and-reset-validation
      $scope.profileForm.$setPristine();
      $scope.profileForm.$setUntouched();
      
      // tell auth to update the user data
      auth.UpdateUserData(userData);
      
    };
    
    /** private behaviour / methods **/
    //
    
    /** run the constructor / startup method **/
    _initialise();

	}
]);