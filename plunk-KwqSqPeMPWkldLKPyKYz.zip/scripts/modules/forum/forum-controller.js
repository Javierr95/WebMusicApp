app.controller ('ForumController', [
	'$scope', 'AuthenticationService', '$localStorage', function ( $scope, auth, $localStorage )
	{
		  
    /** oputput parameter values to console for debug purposes **/
    console.log('ForumController has loaded.');
    console.log('ForumController: $scope:', $scope);
		  
    /****** CONTROLLER CODE ******/
    
    /** public attributes / variables **/
    $scope.forumTitle = 'Forum Title Here';
    $scope.forumView = 'Topics'; // Topics or Posts
    $scope.topicIndex = -1;
    $scope.newPost = {
      content: ''
    };
    $scope.newTopic = {
      title: ''
    };
    
    /** private attributes / variables **/
    // none at the moment
    
    /** constructor / startup method **/
    var _initialise = function () {
      
      console.log("ForumController: _initialise() is running.");
      
      if (!$localStorage.forumData) {
        
        $localStorage.forumData = [];
        
        // set up the mock data
        _SetForumMockData();
        
      }
      
    };
    
    /** public behaviour / methods **/
    $scope.User = function () { 
      return auth.User();
    };
    
    $scope.SwitchForumView = function (forumView, topicIndex) {
      
      console.log("ForumController: SwitchForumView('" + forumView + "', " + topicIndex + ") is running.");
      
      // change the forum view to the requested one
      $scope.forumView = forumView;
      
      // set the topic index that will be used in the view to extract the correct posts for the requested topic
      $scope.topicIndex = topicIndex;
      
    };
    
    $scope.DeleteTopic = function (topicIndex) {
      
      // delete topic from forum data
      $localStorage.forumData.splice(topicIndex, 1);
      
    };
    
    $scope.DeletePost = function (topicIndex, postIndex) {
      
      // delete post from within the chosen topic
      $localStorage.forumData[topicIndex].posts.splice(postIndex, 1);
      
    };
    
    $scope.AddTopic = function () {
      
      var topic = {
        title: $scope.newTopic.title,
        posts: []
      };
      
      $localStorage.forumData.push(topic);
      
      $scope.newTopic.content = "";
      
    }
    
    $scope.AddPost = function (topicIndex) {
      
      var post = {
        content: $scope.newPost.content,
        user: $scope.User().name,
        date: new Date() // today's date
      };
      
      $localStorage.forumData[topicIndex].posts.push(post);
      
      $scope.newPost.content = "";
      
    }
    
    $scope.forumData = function () {
      
      return $localStorage.forumData;
      
    };
    
    /** private behaviour / methods **/
    function _SetForumMockData() {
      
      console.log("ForumController: _SetForumMockData() is running.");
      
      // create some topcis and posts for development purposes
      $localStorage.forumData = [
        {
          title: 'First Topic',
          posts: [
            {
              content: 'First Post',
              user: 'Raz',
              date: new Date() // today's date
            },
            {
              content: 'Second Post',
              user: 'Jim',
              date: new Date() // today's date
            }
          ]
        },
        {
          title: 'Another Topic',
          posts: [
            {
              content: 'First Post, another topic',
              user: 'John',
              date: new Date() // today's date
            },
            {
              content: 'Second Post, weather!',
              user: 'Joey',
              date: new Date() // today's date
            }
          ]
        }
      ];
      
    }
    
    /** run the constructor / startup method **/
    _initialise();

	}
	
]);