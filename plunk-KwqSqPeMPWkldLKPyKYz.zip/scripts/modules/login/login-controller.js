app.controller ('LoginController', [
	'$scope', 'AuthenticationService' ,'$location', function ( $scope, auth, $location )
	{
		  
    /** oputput parameter values to console for debug purposes **/
    console.log('LoginController has loaded.');
		  
    /****** CONTROLLER CODE ******/
    
    /** public ($scope) variables **/
    // 
    
    /** private variables **/
    
    /** constructor **/
    var _initialise = function () {
      //
    };
    
    /** public ($scope) methods **/
    $scope.LoginUser = function () {
      
      var proceed = true;
      
      // check if user exists
      if (auth.AuthenticateUser($scope.user.email, $scope.user.password) == false) {
          
        // user does not exist
        proceed = false;
        
      }
      
      if (!proceed) {
        
        return;
      }
      
      $location.path("/forum");
      
    };
    
    /** private methods **/
    //
    
    /** initialise controller **/
    _initialise();

	}
]);