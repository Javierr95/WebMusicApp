app.service('AuthenticationService', [
  '$rootScope', '$localStorage', function($rootScope, $localStorage) {
    
    /** the service container **/
    var self = this;
    
    /** public variables **/
    
    /** private variables **/
    var user = null;
    
    /** constructor **/
    var _initialise = function () {
      
      if (!$localStorage.users) {
        $localStorage.users = [];
      }
      
      _SetEventListeners();
    
    };
    
    /** public methods **/
    self.User = function () {
      
      return user;
      
    };
    
    self.AddUser = function (user) {
      
      // add to users array
      $localStorage.users.push(user);
      
    };
    
    self.GetAllUsers = function() {
      
      return $localStorage.users;
      
    };
    
    self.GetUserByEmail = function (email) {
      
      for (var i = 0; i < $localStorage.users.length; i++) {
        
        if ($localStorage.users[i].email == email) {
          
          return {
            email: $localStorage.users[i].email,
            name: $localStorage.users[i].name,
            index: i
          };
          
        }
        
      }
      
      return null;
      
    };
    
    self.AuthenticateUser = function (email, password) {
      
      for (var i = 0; i < $localStorage.users.length; i++) {
        
        var userTmp = $localStorage.users[i];
        
        if (userTmp.email == email && userTmp.password == self.EncryptPassword(password)) {
          
          user = {
            email: userTmp.email,
            name: userTmp.name,
            index: i
          };
          
          return true;
          
        }
                
      }
      
      return false;
      
    };
    
    self.EncryptPassword = function (password) {
      
      return btoa(password);
      
    };
    
    self.Logout = function () {
      
      user = null;
      
    };
    
    self.UpdateUserData = function (newUserData) {
      
      // update user info - https://docs.angularjs.org/api/ng/function/angular.merge
      angular.merge($localStorage.users[user.index], newUserData);
      
      // notify any listeners define in _SetEventListeners() and send them the new data
      $rootScope.$emit('userDataChanged', newUserData);
      
    };
    
    /** private methods **/
     var _SetEventListeners = function () {
       
       // if this event is ever triggered / emitted
       $rootScope.$on('userDataChanged', function (event, newUserData) {
         
         // remove the password from the new data if it's there, we don't want the Views to have access to it
         if (newUserData.password) {
           delete newUserData.password;
         }
         
         // update the authenticated user data using the new data
         angular.merge(user, newUserData);
         
       });
       
     };
    
    /** run constructor **/
    _initialise();
    
    return self;
    
  }
]);